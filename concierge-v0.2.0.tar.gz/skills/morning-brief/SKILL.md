---
name: morning-brief
description: |
  Your daily briefing in one short, scannable card: today's calendar, the
  emails that actually need you, the weather, and your to-do list. Calm and
  glance-first, not a wall of text.
  Trigger: "morning brief", "morning briefing", "daily brief", "good morning",
  "start my day", "what's my day look like", "/morning-brief".
  Do NOT use for: a full inbox scan (use /email-digest) or calendar-only
  questions.
---

# Morning Brief

Produce a calm, glance-first daily briefing. Lead with a card the user can
read in ten seconds, then offer the detail that actually needs action.

## Sources (degrade gracefully — never block on a missing one)

| Source | Used for | If unavailable |
|--------|----------|----------------|
| Google Calendar connector | today's schedule | skip section, note once |
| Gmail connector | priority email | skip section, note once |
| WebSearch | today's weather | skip line |
| `~/todo.md` (plain text) | pending actions | skip section |

If Gmail or Calendar isn't connected, tell the user once how to turn it on
(claude.ai → Connectors) and continue with whatever is available. Show what
you have; do not stall.

## Steps

1. **Date + time.** Use the current local time from context.
2. **Schedule.** List today's events (time, title, location). Call out the
   next thing coming up and any overlaps.
3. **Priority email.** Search the last 24 hours of unread / important mail.
   Surface only what needs the user: bills and payments, travel, anything
   asking for a reply, anything time-sensitive. Everything else is "noise" —
   report it as a count, do not list it. Never dump the whole inbox.
4. **Weather.** Today's forecast for the user's location. If you don't know
   their location, ask once and remember it (save to memory or `~/todo.md`).
5. **To-do.** Read `~/todo.md`. Show today's items and anything overdue.

## Output (two messages)

**Message 1 — the GLANCE card.** Short. Roughly:

```
[Weekday, D Month]
☀️  Weather: <one line>
📅  <N> events  ·  next: <HH:MM> <title>
📧  <N> need you  ·  <M> noise
✅  <K> to-dos today
```

**Message 2 — the DETAIL.** Only the items that need action, grouped:

```
📅 Schedule        <each event, conflicts flagged>
📧 Needs you       <sender — one-line why it matters — suggested action>
✅ To-do           <today + overdue>
```

Keep it tight. No filler, no horoscope-speak. If a section is empty, say so in
one line ("Inbox: nothing that needs you.") and move on.

## First-run setup

On the very first run, if you don't yet know the user's location, ask for it
once and save it so future briefs are instant. If `~/todo.md` doesn't exist,
create it with a simple `# To-do` heading so the user has somewhere to add
items.
