# Memory

This is your assistant's long-term memory index. It loads at the start of every
session, so anything noted here is remembered across conversations.

How it works: each durable fact lives in its own file in this folder, and this
file keeps a one-line pointer to it. To save something, ask your assistant to
"remember that ..." and it will write a memory file and add a line here.

A memory file looks like this:

```markdown
---
name: my-coffee-order
description: what I usually order, for quick reference
metadata:
  type: user
---

Flat white, oat milk, one sugar.
```

Types: `user` (who you are, your preferences), `project` (ongoing work),
`reference` (links to dashboards/docs), `feedback` (how you want me to work).

## Your memories

(empty — they'll appear here as you use Concierge)
