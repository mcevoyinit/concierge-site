# General Instructions

- Always run, test, and validate correctness in anything you build. It is vital
  not to return false positives. Ultrathink on these finishing matters.
- When I say "ultrathink", take extra time to verify correctness, check edge
  cases, and validate outputs before responding.
- For major architecture or product decisions, weigh more than one option and
  give a clear recommendation, not just a survey.
- Prefer the simplest thing that works. No unrequested refactors or features.

This setup was installed by Concierge. Type `/oracle` if you're not sure which
skill fits a problem, or just describe what you need.
