---
name: email-digest
description: |
  Scan, categorize, and summarize Gmail emails for a given timeframe. Produces
  an actionable digest with red flags, travel, money moves, bills, personal items,
  and priority action list. Uses Gmail MCP tools (main conversation only).
  Trigger: "email digest", "check my emails", "email summary", "what's in my inbox",
  "scan my gmail", "email report", "/email-digest".
---

# Email Digest

Scan Gmail for a given timeframe and produce a structured, actionable summary.

## Parameters

| Param | Default | Example | Description |
|-------|---------|---------|-------------|
| timeframe | 7 days | "last 3 days", "since march 20", "this week" | How far back to scan |
| focus | all | "travel", "money", "bills", "personal" | Filter to specific category |

## Execution Protocol

### Step 1: Search (broad sweep, noise filtered)

Run the Gmail search with these noise filters applied:

```
after:{DATE} -category:promotions {your noise senders, e.g. -from:noreply@example.com}
```

Use `maxResults: 50` for 7-day windows, `100` for longer periods.

If there's a `nextPageToken` and the timeframe is > 7 days, paginate once more.

### Step 2: Triage

Scan the snippet + headers of every result. Classify each into one of these buckets:

| Bucket | Icon | What goes here |
|--------|------|----------------|
| **RED FLAGS** | | Bounced payments, failed debits, security alerts, urgent deadlines, legal notices |
| **MONEY** | | Bank transfers, withdrawals, deposits, payment confirmations, invoices |
| **TRAVEL** | | Flight bookings, hotel confirmations, check-in reminders, itinerary changes |
| **BILLS & UTILITIES** | | Electricity, water, gas, internet, rent, subscriptions, direct debits |
| **PERSONAL** | | Calendar invites, messages from known contacts, therapy, family |
| **ADMIN** | | Bank T&C updates, KYC requests, contract signings, tax notices |
| **NOISE** | | Newsletters, marketing, generic notifications — skip these |

### Step 3: Deep Read

For anything in RED FLAGS, MONEY, TRAVEL, or ADMIN: read the full message body using `gmail_read_message` or `gmail_read_thread` (for multi-message threads).

For PERSONAL: read only if the snippet suggests something actionable.

For BILLS: read if it looks like a bounced payment or new contract, otherwise snippet is enough.

**Parallelise reads** — call multiple `gmail_read_message` in a single turn where possible.

### Step 4: Output

Produce the digest in this exact format:

```markdown
## Email Digest: {start_date} — {end_date}

---

### RED FLAGS — Action Required
{numbered list with bold subject, sender, date, and what needs to happen}

### MONEY
{table: Date | Amount | From/To | Description}

### TRAVEL
{table with flight/hotel details, booking refs, dates}

### BILLS & UTILITIES
{table: Provider | Amount | Status (paid/bounced/pending)}

### PERSONAL
{brief list of notable personal emails}

### ADMIN
{brief list of admin items needing attention}

---

### Priority Actions
{numbered list, most urgent first, with specific next steps}
```

## Important Notes

- **MCP tools only work in main conversation** — this skill CANNOT run in subagents
- If the user says "ultrathink", read MORE messages in full (not just red flags)
- Always convert dates to the user's timezone (Lisbon/WET, currently WEST UTC+1)
- For financial items, always extract the exact EUR amount
- For travel, always extract booking reference numbers
- For bounced payments, flag the provider AND suggest how to fix
- When you see emails to/from known contacts (your known contacts), categorize as PERSONAL
- Cross-reference with memory for context (e.g. your bank, key counterparties, recent trips)

## Noise Filter List

These senders are always NOISE unless the snippet suggests something actionable:

```
newsletter@example.com
digest@example.com
noreply@rideshare.example (receipts — unless > €50)
noreply@delivery.example
*@bookretreats.com
*@jacksflightclub.com
*@events.example
noreply@community.example (unless event today)
*@saas.example
*@binance.com (marketing — but NOT withdrawal/deposit notifications)
```

## Activation

When the user triggers this skill:

1. Parse the timeframe from their message (default: 7 days)
2. Calculate the `after:` date
3. Execute Steps 1-4 above
4. End with the Priority Actions list

If no timeframe is given, default to 7 days.
